#include<iostream>
#include<conio.h>
#include<stdlib.h>
using namespace std;


int main(){

for(int i=1;i<=5;i++){
int ranDomNumber=rand()%5+1;
 cout<<"Random Number="<<ranDomNumber<<endl;

    }

       getch();
}
