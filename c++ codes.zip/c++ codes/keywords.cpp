#include<iostream>
#include<conio.h>
using namespace std;
int main(){
int i,j;
char ch;
ch='a';
i=10,j=10;
int sum=i+j;

cout<<sum<<endl;
cout<<"number"<<i<<"number2"<<j<<endl<<ch;
getch();
}
