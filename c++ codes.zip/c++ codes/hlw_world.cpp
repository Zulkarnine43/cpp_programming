#include<iostream>
#include<conio.h>
using namespace std;

int main(){
cout<<"Hello \n world!"<<endl;
cout<<"Hi";//print2
getch();

/*
hlow frinend
*/
}
