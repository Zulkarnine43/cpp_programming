
#include<iostream>
using namespace std;

int main(){
double base,height,area;

cout<<"Enter a base ";
cin>>base;

cout<<"Enter a height ";
cin>>height;

area =(double)1/2 *base * height;
cout<<"Area of traiangle "<<area;
}
