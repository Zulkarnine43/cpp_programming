#include<iostream>
#include<conio.h>
using namespace std;

 void square(int n){
    int sum=n*n;
    cout<<"square of "<<n<<"="<<sum<<endl;
    }


int main(){

    square(5);



       getch();
}

