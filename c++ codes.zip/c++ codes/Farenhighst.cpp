
#include<iostream>
using namespace std;

int main(){
double farn,cels;
cout<<"Enter a cels ";
cin>>cels;

farn =1.8*cels +32;
cout<<"Area of traiangle "<<farn;

return 0;
}
