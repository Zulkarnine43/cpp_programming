#include<iostream>
#include<conio.h>
#include<stdio.h>
using namespace std;
int main(){
   // char msg[4]={'Z','U','L'};// ONE CHARCTER EXTRA FOR NULL
       // char msg[]="Zulkar";//
       char msg[10];
       //cin>>msg;
       gets(msg);
    cout<<msg;
    getch();
}
