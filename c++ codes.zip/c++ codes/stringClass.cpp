#include<iostream>
//#include<cstring>
#include<conio.h>
using namespace std;
int main(){
    string str1="Zulkar";
    string str2="Nine";
    string str3=str1;

    string str4=str1+str2;

    cout<<str3<<endl;
    cout<<str4<<endl;

    int len=str1.size();
    cout<<len<<endl;
    getch();
}
