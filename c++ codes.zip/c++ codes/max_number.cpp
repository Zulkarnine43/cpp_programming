#include<iostream>
#include<conio.h>
using namespace std;

int main(){
int num1,num2;
cout<<"Enter a number";
cin>>num1;
cout<<"Enter another number";
cin>>num2;

int max=(num1>num2)?num1:num2;

cout<<max;


getch();
}
