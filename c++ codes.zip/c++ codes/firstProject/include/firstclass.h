#ifndef FIRSTCLASS_H
#define FIRSTCLASS_H



class firstClass
{
    public:
        firstClass();
         ~firstClass();
        void display();

    protected:

    private:
};

#endif // FIRSTCLASS_H
