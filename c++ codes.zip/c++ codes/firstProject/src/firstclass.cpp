#include "firstclass.h"
#include<iostream>
using namespace std;
firstClass::firstClass()
{
    //ctor
    cout<<"constructor is called "<<endl;

}

firstClass::~firstClass()
{
    //ctor
    cout<<"distructor is called "<<endl;

}

void firstClass::display(){
cout<<"Inside the constructor"<<endl;
}
