#include <iostream>
#include "firstclass.h"

using namespace std;

int main()
{
    firstClass ob1;
    ob1.display();
    return 0;
}
