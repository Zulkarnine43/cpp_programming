#include<iostream>
#include<conio.h>
using namespace std;

class student{
public:
    int admissionFee;

    student(int x){
    admissionFee=x;
    }


};

int main(){
student s1(15000);
getch();
}
