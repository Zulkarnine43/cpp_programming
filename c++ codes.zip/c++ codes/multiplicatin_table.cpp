#include<iostream>
#include<conio.h>
using namespace std;

int main(){
int num1;
cout<<"Enter a number";
cin>>num1;

for(int i=0;i<=10;i++){
    cout<<num1<<"X"<<i<<"="<<(num1*i)<<endl;
}



getch();
}
