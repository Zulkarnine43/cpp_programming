#include<iostream>
#include<conio.h>
using namespace std;

int main(){
char name[7]="Zulkar";
cout<<"My name is="<<name;
getch();
}
